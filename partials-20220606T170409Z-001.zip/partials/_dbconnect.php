<?php
 if(($_SERVER['REQUEST_METHOD'] == 'POST')
 {
   /*if(isset($_POST['username']))
   {*/
      $servername = "localhost";
      $username = "root";
      $password = "";
      $database = "users";
      $conn = mysqli_connect($servername, $username, $password, $database);
      if($conn)
      {
        echo "connected";
      }
   
 }
?>